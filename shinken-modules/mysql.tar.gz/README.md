pack-mysql
==========

Shinken configuration pack for MySQL databases
