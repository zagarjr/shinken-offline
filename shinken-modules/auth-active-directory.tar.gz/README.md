mod-auth-active-directory
=========================

Shinken module for UI authentification with Active Directory or OpenLDAP
