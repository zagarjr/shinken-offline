pack-cisco
==========

Shinken configuration pack for Cisco
