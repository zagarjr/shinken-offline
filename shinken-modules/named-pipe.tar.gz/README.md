mod-named-pipe
==============

Shinken module for listening external commands from a Unix named pipe (like Nagios)
