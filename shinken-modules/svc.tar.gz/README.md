pack-svc
========

Shinken configuration pack for IBM SAN Volume Controller
You must install Standard Based Linux Instrumentation package:
- sblim-wbemcli
