mod-canopsis
============

Shinken module for exporting data to Canopsis
