pack-aix
========

Configuration pack for AIX hosts
