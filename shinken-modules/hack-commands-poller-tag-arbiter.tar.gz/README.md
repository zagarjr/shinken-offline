mod-hack-commands-poller-tag-arbiter
====================================

Shinken module for tagging commands with pollerts tags based on their names
