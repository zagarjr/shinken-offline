mod-merlindb
============

Shinken module for exporting data to a OP5/Merlin database (Mysql or sqlite)
