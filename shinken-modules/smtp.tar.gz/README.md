pack-smtp
=========

Shinken configuration pack for SMTP(s)
