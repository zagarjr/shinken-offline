mod-couchdb
===========

Shinken module for sending data to a couchdb server
