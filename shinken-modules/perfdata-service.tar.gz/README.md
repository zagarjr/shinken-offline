mod-perfdata-service
====================

Shinken module for exporting services data to a flat file (Centreon compatibility)
