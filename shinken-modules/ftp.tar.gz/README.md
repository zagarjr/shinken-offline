pack-ftp
========

Shinken configuration pack for FTP
