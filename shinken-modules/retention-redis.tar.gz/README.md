mod-retention-redis
===================

Shinken module for saving retention data from schedulers to a redis server
