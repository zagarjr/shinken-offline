pack-mssql
==========

Shinken configuration pack for Sqlserver databases
