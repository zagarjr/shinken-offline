pack-hp
=======

Shinken configuration pack for HP elements
