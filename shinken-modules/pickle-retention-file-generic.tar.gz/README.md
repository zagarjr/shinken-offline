mod-pickle-retention-file-generic
=================================

Shinken module for saving retention data from Arbiter/Broker to a flat file. Use with care.
