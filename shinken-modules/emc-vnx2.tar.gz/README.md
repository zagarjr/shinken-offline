Shinken pack for EMC VNX2
==============================

Shinken configuration pack for EMC VNX² storage arrays
