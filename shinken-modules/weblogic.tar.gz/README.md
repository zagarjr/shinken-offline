pack-weblogic
=============

Shinken configuration pack for Weblogic hosts. Can check that a Weblogic server is running.
Check presence of ohs, admin console and enterprise manager agent are up.
