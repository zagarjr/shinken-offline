pack-exchange
=============

Shinken configuration pack for Exchange servers
