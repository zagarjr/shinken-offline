mod-hack-poller-tag-by-macros
=============================

Shinken module for tagging hosts poller tag value based on their macros
