pack-ibm-ds
===========

This pack checks sensors (psu, temperature, fans et al) and overall health of
SAN switches that understand the Fibre Alliance MIB. There is a long list of 
companies behind that MIB; I have tested the script with switches from Brocade 
and Qlogic.
