pack-mongodb
============

Shinken configuration pack for authenticated MongoDB databases
