pack-vmware
===========

Shinken configuration pack for VMWare


Requirements :
--------------

- check_esx3.pl plugin : /usr/local/shinken/install -p check_esx3
- check_disk_vcenter.pl plugin : https://github.com/DessaiImrane/check_disk_vcenter.pl
- check_vmi_plus plugin : /usr/local/shinken/install -p check_wmi_plus
- check_vmware_snapshots.pl plugin : http://labs.consol.de/lang/de/nagios/check_vmware_snapshots/ 


