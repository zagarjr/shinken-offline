mod-auth-htpasswd
=================

Shinken module for UI authentification from Apache passwd files
