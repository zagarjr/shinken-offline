pack-emc
========

Shinken configuration pack for ECM²
