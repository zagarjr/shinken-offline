pack-http
=========

Shinken configuration pack for HTTP
