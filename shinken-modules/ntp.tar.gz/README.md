pack-ntp
=========

Shinken configuration pack for NTP
