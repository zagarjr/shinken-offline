mod-import-mysql
================

Shinken module for importing configuration  from a MySQL server
