mod-graphite
============

Shinken module for exporting data to a Graphite server
