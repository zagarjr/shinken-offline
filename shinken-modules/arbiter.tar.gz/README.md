pack-arbiter
============

Checks Shinken Daemons Health


Requirements :
--------------

- check_shinken.py plugin : https://github.com/shinken-monitoring/check_shinken

