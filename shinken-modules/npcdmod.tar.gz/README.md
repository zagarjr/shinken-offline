mod-npcdmod
===========

Shinken module for exporting performance data to a NPCD daemon (PNP4Nagios)
