pack-raspberrypi
================

Shinken configuration pack for Raspberry Pi
