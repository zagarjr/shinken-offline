.. _kiosks_counters_module:

=========================
Kiosks hosts counters
=========================

To be described ...

Requirements 
=============


Configuring module 
=============================

