# mod-kiosks-counters
![Logo IPM France](https://github.com/IPM-France/Software-tools/raw/master/images/IPM_logo.png "Logo")

------
(c) Copyright IPM France SAS / 2013-2014


## Contenu du repository ##

Ce repository contient le plugin Shinken pour g�rer les changements d'�tat des hotes et services.


Documentation
====================

Dans le dossier `doc`, un fichier de documentation.


Source
====================

Dans le dossier `module`, le code source du module.

