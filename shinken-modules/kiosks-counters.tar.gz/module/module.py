#!/usr/bin/python

# -*- coding: utf-8 -*-

import time
import re
import urllib

from shinken.basemodule import BaseModule
from shinken.log import logger
from shinken.misc.perfdata import PerfDatas

properties = {
    'daemons': ['broker'],
    'type': 'kiosks-hostcounters',
    'external': True,
}

def get_instance(plugin):
    logger.info("[Counters] Get a kiosks-hostcounters data module for plugin %s" % plugin.get_name())
    instance = Kiosks_hostcounters(plugin)
    return instance

class Kiosks_hostcounters(BaseModule):
    def __init__(self, modconf):
        BaseModule.__init__(self, modconf)
        
        logger.info("[Counters] Starting...")

        try:
            self.host = getattr(modconf, 'host', '127.0.0.1')
            self.user = getattr(modconf, 'user', 'shinken')
            self.password = getattr(modconf, 'password', 'shinken')
            self.database = getattr(modconf, 'database', 'glpidb')
            self.character_set = getattr(modconf, 'character_set', 'utf8')
            self.svc_perfdata_dict = {}
            self.url = getattr(modconf, 'url', "http://192.168.1.210/glpi/plugins/webservices/rest.php")

            ## Counters
            # Select perfdata regexp
            self.querySelectPerfdatas = "SELECT `kc`.`id`, `kc`.`counter_name`, `kc`.`regexp_perfdata`, `kc`.`counter_type`, `mc`.`name`, `mc`.`description` FROM `glpi_plugin_kiosks_counters` as kc, `glpi_plugin_monitoring_components` as mc WHERE `kc`.`plugin_monitoring_components_id` = `mc`.`id` AND `kc`.`is_active` = 1"
            # Real time value
            self.queryInsertHostcounters = "INSERT INTO `glpi_plugin_kiosks_hostcounters` SET `hostname` = '%s', `entities_id` = '%s', `date` = '%s', `plugin_kiosks_counters_id` = '%s', `value` = '%s', `counter_type` = '%s'"
            # Calculate daily values
            self.queryDailyInsertHostcounters = "INSERT INTO `glpi_plugin_kiosks_hostcounters_daily` SET `hostname`='%s', `entities_id` = '%s', `day`='%s', `plugin_kiosks_counters_id` = '%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=`value`+%s"
            self.queryDailyInsertHostcountersAbs = "INSERT INTO `glpi_plugin_kiosks_hostcounters_daily` SET `hostname`='%s', `entities_id` = '%s', `day`='%s', `plugin_kiosks_counters_id` = '%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=%s"
            # Calculate monthly values
            self.queryMonthlyInsertHostcounters = "INSERT INTO `glpi_plugin_kiosks_hostcounters_monthly` SET `hostname`='%s', `entities_id` = '%s', `month`=MONTH('%s'), `year`=YEAR('%s'), `plugin_kiosks_counters_id` = '%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=`value`+%s"
            self.queryMonthlyInsertHostcountersAbs = "INSERT INTO `glpi_plugin_kiosks_hostcounters_monthly` SET `hostname`='%s', `entities_id` = '%s', `month`=MONTH('%s'), `year`=YEAR('%s'), `plugin_kiosks_counters_id` = '%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=%s"
            # Calculate yearly values
            self.queryYearlyInsertHostcounters = "INSERT INTO `glpi_plugin_kiosks_hostcounters_yearly`  SET `hostname`='%s', `entities_id` = '%s', `year`=YEAR('%s'), `plugin_kiosks_counters_id` = '%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=`value`+%s;";
            self.queryYearlyInsertHostcountersAbs = "INSERT INTO `glpi_plugin_kiosks_hostcounters_yearly`  SET `hostname`='%s', `entities_id` = '%s', `year`=YEAR('%s'), `plugin_kiosks_counters_id` = '%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=%s;";
            # Calculate eternal values
            self.queryAllInsertHostcounters = "INSERT INTO `glpi_plugin_kiosks_hostcounters_all` SET `hostname`='%s', `entities_id` = '%s', `plugin_kiosks_counters_id` = '%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=`value`+%s"
            self.queryAllInsertHostcountersAbs = "INSERT INTO `glpi_plugin_kiosks_hostcounters_all` SET `hostname`='%s', `entities_id` = '%s', `plugin_kiosks_counters_id` = '%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=%s"

            ## Conditional Counters
            # Select conditional counters params
            self.querySelectCondCounters = "SELECT `plugin_kiosks_counters_name`, `counter_name`, `condition`, `condition_value`, `action`, `action_value` FROM `glpi_plugin_kiosks_condcounters` WHERE `is_active` = 1"
            # Calculate conditional counters
            self.queryActionCondCounter = "INSERT INTO `glpi_plugin_kiosks_hostcounters_cond` SET `hostname`='%s', `counter`='%s', `day`='%s', `value`=%s ON DUPLICATE KEY UPDATE `value`=%s,`day`='%s'"
            
            ## Record Counters
            # Just Insert the value
            self.queryInsertHostcountersRecord = "INSERT INTO `glpi_plugin_kiosks_records` SET `hostname` = '%s', `date` = '%s', `plugin_kiosks_counters_id` = '%s', `value` = '%s'";

            ## Select Hostname - Entity Id
            self.querySelectHostnameEntity = "SELECT name, entities_id FROM `glpi_computers`"

            ## Select last values 
            self.querySelectLastValues = "SELECT `hostname`,`glpi_plugin_kiosks_counters`.`counter_name`,`value`, `date` FROM `glpi_plugin_kiosks_hostcounters_lastvalues` AS hlva LEFT JOIN `glpi_plugin_kiosks_counters` ON hlva.`plugin_kiosks_counters_id` = `glpi_plugin_kiosks_counters`.`id` WHERE `date` = ( SELECT MAX(`date`) FROM `glpi_plugin_kiosks_hostcounters_lastvalues` AS hlvb WHERE hlva.`hostname` = hlvb.`hostname` AND hlva.`plugin_kiosks_counters_id` = hlvb.`plugin_kiosks_counters_id` ) AND `glpi_plugin_kiosks_counters`.`is_active` = 1 GROUP BY `hostname`,`glpi_plugin_kiosks_counters`.`counter_name`"

            self.queryLastValues = "INSERT INTO `glpi_plugin_kiosks_hostcounters_lastvalues` SET `hostname` = '%s', `date` = '%s', `plugin_kiosks_counters_id` = '%s', `value` = '%s' ON DUPLICATE KEY UPDATE `value` = '%s'"

        except AttributeError:
            logger.error("[Counters] The module is missing a property, check module configuration in kiosks-hostcounters.cfg")
            raise
            
    def init(self):
        import MySQLdb
        logger.debug("[Counters] Creating a MySQL backend : %s (%s)" % (self.host, self.database))
        logger.debug("[Counters] Connecting to database ...")
        db = MySQLdb.connect(self.host, self.user, self.password, self.database)
        self.db_backend = db.cursor()
        logger.debug("[Counters] Connected")
        
        ## Getting Hostname - Entities Id
        try:
            logger.info("[Counters] Getting (hostname/entity_id) from MySQL")
            self.db_backend.execute(self.querySelectHostnameEntity)
            self.entities = {}
            rows = self.db_backend.fetchall()
            for row in rows:
                logger.debug("[Counters] %s - %s " % (row[0], row[1]))
                # row[0] : name
                # row[1] : entities_id
                self.entities[row[0]] = row[1]
            logger.info("[Counters] Got (hostname/entity_id): %d", len(rows))
            logger.debug("[Counters] Got (hostname/entity_id) %s " % self.entities)
        except AttributeError:
            logger.error("[Counters] Error in getting (hostname/entity_id) from MySQL")
            raise
            
        ## Getting PerfDatas
        try:
            logger.info("[Counters] Getting perfdatas regexp from MySQL")
            self.db_backend.execute(self.querySelectPerfdatas)
            self.dperfdata = []
            rows = self.db_backend.fetchall()
            for row in rows:
                logger.debug("[Counters] %s - %s - %s - %s - %s" % (row[0], row[1], row[2], row[3], row[4]))
                # row[0] : kiosks_counter.id
                # row[1] : kiosks_counter.counter_name
                # row[2] : kiosks_counter.regexp_perfdata
                # row[3] : kiosks_counter.counter_type
                # row[4] : monitoring_components.name
                # row[5] : monitoring_components.description
                d = {'id': row[0], 'counter_name': row[1], 'regexp_perfdata': row[2], 'counter_type': row[3], 'alias': row[4], 'description': row[5]}
                self.dperfdata.append(d)

            logger.info("[Counters] Got perfdatas regexp: %d", len(rows));
            logger.debug("[Counters] Got perfdatas regexp %s" % self.dperfdata);
        except AttributeError:
            logger.error("[Counters] Error in getting perfdatas from MySQL")
            raise
        
        ## Getting Conditional Counters
        try:
            logger.info("[Counters] Getting conditional counters from MySQL")
            self.db_backend.execute(self.querySelectCondCounters)
            self.dconds = []
            rows = self.db_backend.fetchall()
            for row in rows:
                logger.debug("[Counters] %s - %s - %s - %s - %s" % (row[0], row[1], row[2], row[3], row[4]))
                # row[0] : Plugin Counter Name 
                # row[1] : Counter Name 
                # row[2] : Condition
                # row[3] : Condition Value
                # row[4] : Action 
                # row[5] : Action Value
                d = {'plugin_counter_name': row[0], 'counter_name': row[1], 'condition': row[2], 'condition_value': row[3], 'action': row[4], 'action_value': row[5]}
                self.dconds.append(d)

            logger.info("[Counters] Got cond counters: %d", len(rows));
            logger.debug("[Counters] Got cond counters %s" % self.dconds);
        except AttributeError:
            logger.error("[Counters] Error in cond counters from MySQL")
            raise
        
        ## Getting Last values
        try:
            logger.info("[Counters] Getting counters last value from MySQL")
            self.db_backend.execute(self.querySelectLastValues)
            rows = self.db_backend.fetchall()
            for row in rows:
                logger.debug("[Counters] Last value: (%s/%s) = %s" % (row[0], row[1], row[2]))
                # row[0] : hostname
                # row[1] : counter name
                # row[2] : value
                self.svc_perfdata_dict[(row[0], row[1])] = row[2]

            logger.info("[Counters] Got counters last value: %d", len(rows) );
            logger.debug("[Counters] Got counters last value %s" % self.svc_perfdata_dict);
        except:
            logger.error("[Counters] Error in counters last value from MySQL")
            raise

    # A service check result brok has just arrived, ...
    def manage_service_check_result_brok(self, b):
        import urllib

        # Broke values
        bHostname = b.data['host_name']
        try:
            bEntityId = self.entities[bHostname]
        except:
            logger.debug("[Counters] Entity Id not found for '%s'" % bHostname)
            bEntityId = '0'
        bId = b.data['current_event_id']
        bServiceDescription = b.data['service_description']
        bState = b.data['state']
        bPerfData = b.data['perf_data']
        bLastCheck = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(b.data['last_chk'])))
        bLastcheckDay, rest = bLastCheck.split(' ', 1)

        for dperfdata in self.dperfdata:
            # SQL Counter values
            counterNameId = dperfdata['id']
            counterName = dperfdata['counter_name']
            counterValue = self.get_counter_value(bId, bPerfData, dperfdata['regexp_perfdata'])
            counterValueToSave = counterValue
            counterType = dperfdata['counter_type']
            # logger.warning("[Counters] get_counter_value, %s : %s = %s" % (bId, counterName, counterValue))

            if dperfdata['description'] == bServiceDescription:

                logger.debug("[Counters] counter : '%s/%s': '%s' (%s) - %s" % (bHostname, bServiceDescription, counterName, counterType, dperfdata['regexp_perfdata']))
                # Store record type as is and continue
                if counterType == 'record':
                    try: 
                        if (counterValue != None):
                            queryInsertHostcountersRecord = self.queryInsertHostcountersRecord % (bHostname, bLastCheck, counterNameId, counterValue)
                            logger.warning("[Counters] record : sql '%s'" % queryInsertHostcountersRecord)
                            self.mysqlExecute(queryInsertHostcountersRecord)
                        continue

                    except Exception, err:
                        logger.error("[Counters] Error when querying '%s' : '%s'" % (self.queryInsertHostcountersRecord, err))
                        continue
                    
                if counterValue is not None:
                    # logger.info ("[Counters] counter value : '%s/%s': '%s' = %s" % (bHostname, bServiceDescription, counterName, counterValue))
                    if counterType == 'differential' or counterType == 'storing':
                        try:
                            counterValuePrev = self.svc_perfdata_dict[(bHostname, counterName)]
                            logger.debug("[Counters] (%s) Previous perf_data : %s" % (bId, counterValuePrev))
                            delta = int(counterValueToSave) - int(counterValuePrev)
                            logger.debug("[Counters] (%s) Delta : %s" % (bId, delta))

                            if delta < 0:
                                logger.warning("[Counters] Negative delta : %s, %s -> %s, storing 0" % (counterName, counterValue, counterValuePrev))
                                counterValueToSave = 0
                                self.svc_perfdata_dict[(bHostname, counterName)] = counterValue
                                self.queryInsertLastvalues(bHostname, bLastCheck, counterNameId, counterValue)

                            else:
                                # May be a problem with this test when a host prints pages and don't talk with the server for a long time
                                # A counter can grow and it make no difference with a new printer with a high counter pages
                                if delta > 2000000000:
                                    logger.warning("[Counters] Important Cut positive delta : %s, %s vs %s, do not store it'" % (counterName, counterValue, counterValuePrev))
                                    counterValueToSave = 0
                                # if delta > 100:
                                #     logger.warning("[Counters] Important Cut positive delta : %s, %s vs %s, storing it anyway !" % (counterName, counterValue, counterValuePrev))
                                #     counterValueToSave = delta
                                    # counterValueToSave = 0
                                    # self.svc_perfdata_dict[(bHostname, counterName)] = counterValue
                                    # self.queryInsertLastvalues(bHostname, bLastCheck, counterNameId, counterValue)

                                else:
                                    logger.debug("[Counters] (%s) Delta: %s, %s -> %s, storing delta" % (bId, counterName, counterValue, counterValuePrev))
                                    counterValueToSave = delta

                        except:
                            logger.info("[Counters] No previous value for: %s @%s, storing absolute value: %s = %s" % (bHostname, bLastCheck, counterName, counterValueToSave))
                            self.svc_perfdata_dict[(bHostname, counterName)] = counterValueToSave
                            self.queryInsertLastvalues(bHostname, bLastCheck, counterNameId, counterValueToSave)
                            continue

                    if counterValueToSave == 0:
                        continue
                        
                    # Store new perfdata as previous ...
                    logger.debug("[Counters] Saving Data : CounterName : '%s' CounterValue : '%s' CounterType : '%s' CounterValueToSave '%s'" % (counterName, counterValue, counterType, counterValueToSave))
                    self.queryInsertCounter(bId, bHostname, bEntityId, bLastCheck, counterNameId, counterValueToSave, counterType, counterValue)
                    self.svc_perfdata_dict[(bHostname, counterName)] = counterValue
                    self.queryInsertLastvalues(bHostname, bLastCheck, counterNameId, counterValue)

                    # Calculate Conditional counters
                    for dcond in self.dconds:
                        found = 0
                        if counterName == dcond['plugin_counter_name']:
                            if dcond['condition'] == 'equals' and int(counterValueToSave) == int(dcond['condition_value']):
                                found = 1
                            elif dcond['condition'] == 'notequals' and int(counterValueToSave) != int(dcond['condition_value']):
                                found = 1
                            elif dcond['condition'] == 'morethan' and int(counterValueToSave) > int(dcond['condition_value']):
                                found = 1
                            elif dcond['condition'] == 'lessthan' and int(counterValueToSave) < int(dcond['condition_value']):
                                found = 1
                            logger.debug("[Counters] found = %s - counter to save = %s - dond value = %s" % (found,counterValueToSave, dcond['condition_value']))
                            if found:
                                logger.debug("[Counters] cond = %s" % str(dcond))
                                # WS
                                uri = "?method=kiosks.pushCondCounterValue&hostname=%s&entityId=%s&dcond=%s&counterNameId=%s&counterName=%s&conditionValue=%s&counterValueToSave=%s" % (bHostname, bEntityId, dcond['condition'], counterNameId, counterName, dcond['condition_value'], str(counterValueToSave))
                                url = self.url + uri
                                logger.warning("[Counters] url = %s" % url)
                                try:
                                    fp = urllib.urlopen(url)
                                    # page = fp.read()
                                    fp.close()
                                except Exception, err:
                                    logger.error("[Counters] Error in url '%s' : '%s'" % (url, err))
                                    continue

                                if dcond['action'] == "addvalue":
                                    condinitvalue = dcond['action_value']
                                    condvalue = "`value`+"+dcond['action_value']

                                elif dcond['action'] == "removevalue":
                                    condinitvalue = "-"+dcond['action_value']
                                    condvalue = "`value`+"+dcond['action_value']

                                elif dcond['action'] == "setvalue":
                                    condinitvalue = dcond['action_value']
                                    condvalue = dcond['action_value']

                                elif dcond['action'] == "addcounter":
                                    condinitvalue = counterValueToSave
                                    condvalue = "`value`+"+str(counterValueToSave)

                                elif dcond['action'] == "removecounter":
                                    condinitvalue = "-"+str(counterValueToSave)
                                    condvalue = "`value`-"+str(counterValueToSave)

                                elif dcond['action'] == "setcounter":
                                    condinitvalue = str(counterValueToSave)
                                    condvalue = str(counterValueToSave)

                                else:
                                    continue
                                
                                logger.debug("[Counters] cond init '%s' et cond value '%s'" % (condinitvalue, condvalue))
                                try:
                                    queryCond = self.queryActionCondCounter % (bHostname, dcond['counter_name'], bLastcheckDay, condinitvalue, condvalue, bLastcheckDay)
                                except:
                                    logger.error("[Counters] Error in queryCond")
                                self.mysqlExecute(queryCond)
                                    
                else:
                    continue

        return

    def get_counter_value(self, bId, perf_data, regexp_perfdata):
        res = None
        logger.debug("[Counters] get_counter_value: %s " % bId)
        if perf_data:
            m = re.search(regexp_perfdata, perf_data)
            if m:
                res = m.group(1)
                logger.debug("[Counters] get_counter_value, res: %s " % res)
                # logger.warning("[Counters] counter: '%s' - '%s' - '%s'" % (counterValue,bPerfData,dperfdata['regexp_perfdata']));

        if not res == None:
            logger.debug("[Counters] (%s) get_metric : %s" % (bId, res))
        return res

    def queryInsertCounter (self, bId, bHostname, bEntityId, bLastCheck, counterNameId, counterValueToSave, counterType, counterValue):

        if counterType == 'storing':
            try:
                queryInsert = self.queryInsertHostcounters % (bHostname, bEntityId, bLastCheck, counterNameId, counterValue, counterType)
                logger.debug("[Counters] SQL Insert : %s" % (queryInsert))
                self.mysqlExecute(queryInsert)
            except:
                logger.error("[Counters] (%s) Error when querying: %s" % (bId, self.queryInsertHostcounters))
                logger.error("[Counters] (%s) Datas : `hostname` = '%s', `date` = '%s', `counter` = '%s', `value` = '%s', `counterType` = '%s'" % (bId, bHostname, bLastCheck, counterNameId, counterValue, counterType))
                pass
        else:
            try:
                queryInsert = self.queryInsertHostcounters % (bHostname, bEntityId, bLastCheck, counterNameId, counterValueToSave, counterType)
                logger.debug("[Counters] SQL Insert : %s" % (queryInsert))
                self.mysqlExecute(queryInsert)
            except:
                logger.error("[Counters] (%s) Error when querying: %s" % (bId, self.queryInsertHostcounters))
                logger.error("[Counters] (%s) Datas : `hostname` = '%s', `date` = '%s', `counter` = '%s', `value` = '%s', `counterType` = '%s'" % (bId, bHostname, bLastCheck, counterNameId, counterValueToSave, counterType))
                pass


        bLastcheckDay, rest = bLastCheck.split(' ', 1)

        if counterType == 'differential' or counterType == 'accumulative' or counterType == 'storing':
            queryDailyInsert = self.queryDailyInsertHostcounters % (bHostname, bEntityId, bLastcheckDay, counterNameId, int(counterValueToSave), int(counterValueToSave))
            queryMonthlyInsert = self.queryMonthlyInsertHostcounters % (bHostname, bEntityId, bLastcheckDay, bLastcheckDay, counterNameId, int(counterValueToSave), int(counterValueToSave))
            queryYearlyInsert = self.queryYearlyInsertHostcounters % (bHostname, bEntityId, bLastcheckDay, counterNameId, int(counterValueToSave), int(counterValueToSave))
            queryAllInsert = self.queryAllInsertHostcounters % (bHostname, bEntityId, counterNameId, int(counterValueToSave), int(counterValueToSave))

        self.mysqlExecute(queryDailyInsert)
        self.mysqlExecute(queryMonthlyInsert)
        self.mysqlExecute(queryYearlyInsert)
        self.mysqlExecute(queryAllInsert)
            
    def queryInsertLastvalues (self, bHostname, bLastCheck, counterNameId, counterValue):
        try:
            queryLastvalue = self.queryLastValues % (bHostname, bLastCheck, counterNameId, counterValue, counterValue)
            logger.debug("[Counters] SQL last value Insert : %s" % (queryLastvalue))
            self.mysqlExecute(queryLastvalue)
        except:
            logger.error("[Counters] Error when querying: %s" % (self.queryLastValues))
            logger.error("[Counters] Datas : `hostname` = '%s', `date` = '%s', `counter` = '%s', `value` = '%s'" % (bHostname, bLastCheck, counterNameId, counterValue))
            pass

    def mysqlExecute(self, sql):
        logger.debug("[Counters] Query mysqlExecute : %s" % (sql))
        try:
            self.db_backend.execute(sql)
        except MySQLdb.Error, e:
            logger.error("[Counters] MySQL Error [%d]: %s" % (e.args[0], e.args[1]))
            logger.error("[Counters] Error when querying: %s" % (sql))

    def manage_brok(self, b):
        if b.type in ('service_check_result'):
            logger.debug("[Counters] '%s'/'%s'" % (b.data['host_name'], b.data['service_description']))
            BaseModule.manage_brok(self, b)

    def main(self):
        self.set_proctitle(self.name)
        self.set_exit_handler()
        while not self.interrupted:
            l = self.to_q.get()
            for b in l:
                b.prepare()
                self.manage_brok(b)
