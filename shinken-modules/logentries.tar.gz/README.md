mod-logentries
==============

To get started configure your Logentries Plugin to send log data to your account.

* Open /etc/modules/logentries.cfg.
* For the Token Parameter enter in your Log Token which you would of obtained when creating a Token TCP log.
* For more information on Token TCP see our [documentation](https://logentries.com/doc/input-token/).
* Once running you should be able to see your logs in [real time](https://logentries.com/doc/live-tail/).
