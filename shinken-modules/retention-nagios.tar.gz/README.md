mod-retention-nagios
====================

Shinken module for loading Nagios retention data. Load only (no write). For migration.
