pack-nortel
===========

Shinken configuration pack for Nortel
