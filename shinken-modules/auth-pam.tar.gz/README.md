mod-auth-pam
============

pam authentication for shinken webui

can use together with IdM/IPA and sssd to provide centralized user authentication

require simplepam [https://github.com/leonnnn/python3-simplepam], you can install via 

    pip install simplepam
