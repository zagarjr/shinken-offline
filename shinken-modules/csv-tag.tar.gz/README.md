mod-csv-tag
===========

Shinken module for tagging hosts based on a CSV file
