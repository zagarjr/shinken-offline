pack-ibm-ds
===========

Shinken configuration pack for IBM Storage. Need IBM Storage Manager CLI. Go on:
http://www-933.ibm.com/support/fixcentral/swg/selectFixes?parent=Entry-level+disk+systems&product=ibm/Storage_Disk/DS3500&release=All&platform=All&function=all#Storage%20Manager
to download Linux Storage Manager according to your CPU arch.
