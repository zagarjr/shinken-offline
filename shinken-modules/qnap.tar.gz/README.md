pack-qnap
=======

Shinken configuration pack about qnap nas that will monitor disks and nas temperature
