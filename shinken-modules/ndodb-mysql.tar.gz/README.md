mod-ndodb-mysql
===============

Shinken module for exporting data to a NDO database (mysql)
