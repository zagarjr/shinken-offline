pack-hp-blades-chassis
======================

Shinken configuration pack for HP Blades C7000 chassis
