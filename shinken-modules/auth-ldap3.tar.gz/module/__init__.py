# coding: utf-8
"""Shinken WebUI LDAPv3 authentication module"""
from __future__ import unicode_literals
