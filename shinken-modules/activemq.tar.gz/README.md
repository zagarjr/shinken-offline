pack-activemq
=========

Shinken configuration pack for ActiveMQ
