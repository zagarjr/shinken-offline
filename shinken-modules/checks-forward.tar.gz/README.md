===============================
Checks forward module
===============================

Shinken module to forward checks result to another Shinken instance using NSCA.

Please [see here](doc/index.rst)
