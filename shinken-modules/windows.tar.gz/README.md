pack-windows
===========

Shinken configuration pack for Windows hosts
