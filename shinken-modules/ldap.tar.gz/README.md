pack-ldap
=========

Shinken configuration pack for LDAP(s)
