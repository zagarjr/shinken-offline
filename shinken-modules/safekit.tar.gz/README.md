pack-safekit
============

Shinken configuration pack for Safekit
