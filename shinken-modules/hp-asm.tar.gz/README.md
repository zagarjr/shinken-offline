pack-hp-asm
===========

Shinken configuration pack for HP servers
