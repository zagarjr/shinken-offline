### 0.2.0
* add signal handling
* add timestamp