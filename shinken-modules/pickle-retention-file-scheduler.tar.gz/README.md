mod-pickle-retention-file-scheduler
===================================

Shinken module for saving retention data from schedulers to a flat file.
