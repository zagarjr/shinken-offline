
# Reader's advice

The previous content of this directory has been removed. 

The most recent documentation is available in the project Wiki: https://github.com/shinken-monitoring/mod-webui/wiki
