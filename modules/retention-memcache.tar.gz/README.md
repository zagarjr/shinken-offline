mod-retention-memcache
======================

Shinken module for saving retention data from schedulers to a memcache server
