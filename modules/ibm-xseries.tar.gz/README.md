pack-ibm-xseries
========

Configuration pack for IBM xSeries server.
Copy/paste ipmi.conf.example in plugins directory
as ipmi.conf and modify it to fit your ipmi settings
