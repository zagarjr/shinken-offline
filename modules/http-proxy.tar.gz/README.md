pack-http-proxy
=========

Shinken configuration pack for HTTP forward proxy
