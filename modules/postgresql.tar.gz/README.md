python-postgresql
=================

Shinken configuration pack for PostgreSQL databases
