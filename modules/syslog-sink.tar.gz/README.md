mod-syslog-sink
===============

Shinken module for exporting all logs into syslog
