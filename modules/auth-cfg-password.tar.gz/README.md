mod-auth-cfg-password
=====================

Shinken module for UI authentification from simple password for configuration file
