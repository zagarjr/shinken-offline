This pack is used to monitor a variety of a Red Hat Enterprice Virtualization (RHEV) and oVirt environement including datacenters, clusters, hosts, vms, vm pools and storage domains.
