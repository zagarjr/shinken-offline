pack-server-ipmi
========

Server hardware monitoring configuration pack.
Copy/paste ipmi.conf.example in plugins directory
as ipmi.conf and modify it to fit your ipmi settings

Copy it as many times is necessary into multiple ipmi.conf
to fit multiple server brand connexion credentials.
