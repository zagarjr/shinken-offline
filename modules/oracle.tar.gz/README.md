pack-oracle
===========

Shinken configuration pack for Oracle Databases
