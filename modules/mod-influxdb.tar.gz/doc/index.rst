============================
mod-influxdb's documentation
============================


.. toctree::
    :maxdepth: 2

    installation 
    configuration
