mod-influxdb [![Build Status](https://travis-ci.org/savoirfairelinux/mod-influxdb.svg?branch=master)](https://travis-ci.org/savoirfairelinux/mod-influxdb) [![Coverage Status](https://img.shields.io/coveralls/savoirfairelinux/mod-influxdb.svg)](https://coveralls.io/r/savoirfairelinux/mod-influxdb?branch=master)
============

Shinken module for exporting data to an InfluxDB server

The module requires the following:
- InfluxDB >= 0.9.0
- Shinken >= 2.4
- influxdb-python >= 2.0.1
