pack-router
===========

Shinken configuration pack for routers
