pack-unix-fs
=========

Templates examples to use with fs_discovery tag mode.
Please choose between tag or macros mode in discovery.cfg file.
