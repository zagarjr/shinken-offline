mod-mongodb
===========

Shinken module used by others modules for mongodb connections



Changelog
=========


1.2 (2014/08/25): 
    Add: (from: VicThor) replicatset managment

