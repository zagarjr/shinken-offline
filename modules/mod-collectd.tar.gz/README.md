mod-collectd
============

Shinken module for listening data from Collectd hosts
