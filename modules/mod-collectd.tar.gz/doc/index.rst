.. mod-collectd documentation master file, created by
   sphinx-quickstart on Wed Feb 26 12:29:52 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

============================
mod-collectd's documentation
============================


.. toctree::
    :maxdepth: 2

    installation 
    configuration
    collectd_dev
