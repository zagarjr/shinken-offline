.. _collectd_dev:


Collectd Developer Reference
============================

.. automodule:: module.module
    :members:
    :undoc-members:
    :show-inheritance:
