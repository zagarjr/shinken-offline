mod-sqlitelog
=============

Shinken module for storing data in a sqlite database.
