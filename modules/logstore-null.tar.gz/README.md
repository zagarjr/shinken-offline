mod-logstore-null
=================

Shinken module for exporting logs to /dev/null from the Livestatus module
