mod-android-sms
===============

Shinken module for sending/receive SMS from an Android Phone
