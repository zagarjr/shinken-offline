pack-switch
===========

Shinken configuration pack for Switch
