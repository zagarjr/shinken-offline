mod-riemann [![Build Status](https://travis-ci.org/savoirfairelinux/mod-riemann.svg)](https://travis-ci.org/savoirfairelinux/mod-riemann) [![Coverage Status](https://img.shields.io/coveralls/savoirfairelinux/mod-riemann.svg)](https://coveralls.io/r/savoirfairelinux/mod-riemann)
============

Shinken module for exporting data to Riemann
