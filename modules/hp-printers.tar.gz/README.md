pack-hp-printers
================

Shinken configuration pack for HP printers with JetDirect
