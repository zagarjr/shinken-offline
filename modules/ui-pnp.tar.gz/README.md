mod-ui-pnp
==========

Shinken module for enabling graphs from PNP4Nagios into WebUI
