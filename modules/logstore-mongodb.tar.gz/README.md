mod-logstore-mongodb
====================

Shinken module for exporting logs to mongodb from the Livestatus module
