pack-printers
=============

Shinken configuration pack for printers
