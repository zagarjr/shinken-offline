pack-asterisk
=============

Shinken configuration pack for Asterisk
