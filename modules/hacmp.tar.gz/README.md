pack-hacmp
==========

Shinken configuration pack for HACMP
