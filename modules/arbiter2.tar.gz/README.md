## arbiter2

shinken pack for monitoring shinken 2.x.x daemons.

You will need to install the requests module

```
pip install requests
```
