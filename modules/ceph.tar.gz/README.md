# pack-ceph

Shinken configuration pack for Ceph
