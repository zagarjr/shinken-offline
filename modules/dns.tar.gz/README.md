pack-dns
========

Shinken configuration pack for DNS
