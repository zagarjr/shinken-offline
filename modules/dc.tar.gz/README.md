pack-dc
=======

Shinken configuration pack for Active Directory controler
