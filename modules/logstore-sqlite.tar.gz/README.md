<a href='https://travis-ci.org/shinken-monitoring/mod-logstore-sqlite'><img src='https://api.travis-ci.org/shinken-monitoring/mod-logstore-sqlite.svg?branch=master' alt='Travis Build'></a>
mod-logstore-sqlite
===================

Shinken module for exporting logs to a sqlite db from the Livestatus module
