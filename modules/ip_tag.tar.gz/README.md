mod-ip-tag
==========

Shinken module for tagging hosts based on their IP range
