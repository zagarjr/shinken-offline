mod-status-dat
==============

Shinken module for exporting data to a Nagios status.dat compatible format
