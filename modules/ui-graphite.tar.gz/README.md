mod-ui-graphite
===============

Description
-----------
Shinken module for enabling graphs from Graphite into WebUI

Installation
------------
`$ shinken install ui-graphite`