glances
=======

shinken pack for standard system monitoring through glances and checkglances plugin.

You need to setup glances as a server on each monitored nodes (curently linux only)

Documentation : https://david-guenault.github.io/shinken-packs.html

glances : http://nicolargo.github.io/glances/

checkglances : http://nicolargo.github.io/checkglances/




