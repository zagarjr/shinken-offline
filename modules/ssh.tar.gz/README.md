pack-ssh
========

Shinken configuration pack for SSH
