mod-perfdata-host
=================

Shinken module for exporting host data to a flat file (Centreon compatibility)
