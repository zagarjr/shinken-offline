mod-file-tag
============

Shinken module for tagging hosts based on a flat file
