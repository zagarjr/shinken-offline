mod-simple-log
==============

Shinken module for exporting all logs intoa common flat file.
