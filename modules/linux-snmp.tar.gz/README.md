pack-linux-snmp
==========

Configuration pack for Linux hosts based on SNMP checks
