===============================
Glpi WS authentication module
===============================

Shinken module to authenticate WebUI users upon a GLPI database.

Please see: https://github.com/shinken-monitoring/mod-auth-ws-glpi/blob/master/doc/index.rst
