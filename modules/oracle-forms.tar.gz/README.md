pack-oracle-forms
=================

Shinken configuration pack for Oracle forms
