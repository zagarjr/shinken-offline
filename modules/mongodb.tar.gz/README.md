pack-mongodb
============

Shinken configuration pack for MongoDB databases
