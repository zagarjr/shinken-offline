pack-collectd
=============

Shinken configuration pack for collectd hosts
