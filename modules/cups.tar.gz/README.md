pack-cups
=========

Shinken configuration pack for CUPS 
