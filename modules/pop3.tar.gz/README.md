pack-pop3
=========

Shinken configuration pack for POP3(s)
