mod-sqlitedb
============

Shinken module used by others modules for Sqlite connections
