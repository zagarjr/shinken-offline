create table service(name varchar(10), instance_id int);
insert into service values('Shinken', 0);
insert into service values('Is Fun', 1);

