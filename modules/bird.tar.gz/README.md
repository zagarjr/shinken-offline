pack-bird
==========

Shinken configuration pack for bird daemon. Bird is a BGP routing software.

