glances
============

shinken pack for standard system monitoring through glances and checkglances plugin.

You need to setup glances as a server on each monitored nodes (curently linux only)

See glances and checkglances pages for installation instructions

glances : http://nicolargo.github.io/glances/
checkglances : http://nicolargo.github.io/checkglances/

also see github repo for initd script for debian


