Welcome to py2pack's documentation!
===================================

py2pack allows to generate RPM spec or DEB dsc files from
Python modules, to list Python modules or search for them on
the Python Package Index (PyPI). Conveniently, it can fetch
tarballs and changelogs making it an universal tool to
package Python modules.

.. toctree::
   :maxdepth: 2

   templates
   cli


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

